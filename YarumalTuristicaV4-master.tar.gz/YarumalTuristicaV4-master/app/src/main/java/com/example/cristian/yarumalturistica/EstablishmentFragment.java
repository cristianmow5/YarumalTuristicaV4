package com.example.cristian.yarumalturistica;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

/**
 * Created by cristian on 10/03/17.
 */

public class EstablishmentFragment extends Fragment implements OnMapReadyCallback   {

    OnMapsSelectedListener mCallback;

    // The container Activity must implement this interface so the frag can deliver messages
    public interface OnMapsSelectedListener {
        /** Called by HeadlinesFragment when a list item is selected */
        public void onMapSelected(int position);
    }

    private static final String ARG_SECTION_IMAGE_NUMBER = "section_image_number";
    private static final String ARG_SECTION_TEXT_NUMBER = "section_text_number";

    private MapView mapView;
    private GoogleMap mMap;

    public EstablishmentFragment() {
    }

    public static EstablishmentFragment newInstance(int sectionImageNumber,
                                                    int sectionTextNumber) {

        EstablishmentFragment fragment = new EstablishmentFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_SECTION_IMAGE_NUMBER, sectionImageNumber);
        args.putInt(ARG_SECTION_TEXT_NUMBER, sectionTextNumber);
        fragment.setArguments(args);
        return fragment;

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_establishment, container, false);
        //TextView textView = (TextView) rootView.findViewById(R.id.section_label);
        //textView.setText(getString(R.string.section_format, getArguments().getInt(ARG_SECTION_IMAGE_NUMBER)));

        TextView textView = (TextView) rootView.findViewById(R.id.textViewEstablishment);
        textView.setText(getArguments().getInt(ARG_SECTION_TEXT_NUMBER));

        ImageView imageView = (ImageView) rootView.findViewById(R.id.imageViewEstablishment);
        imageView.setImageResource(getArguments().getInt(ARG_SECTION_IMAGE_NUMBER));

        return rootView;

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        mMap.setMyLocationEnabled(true);

        mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);

        LatLng udea = new LatLng(6.266953,-75.569111);
        mMap.addMarker(new MarkerOptions()
                .position(udea)
                .title("Univerisdad de Antioquia")
                //.icon(BitmapDescriptorFactory.fromResource(R.drawable.book))
                .snippet("Nuestra Alma máter"));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(udea,15));
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        Activity activity = getActivity();

        // This makes sure that the container activity has implemented
        // the callback interface. If not, it throws an exception.
        /*
             The Fragment captures the interface implementation during
             its onAttach() lifecycle method and can then call
             the Interface methods in order to communicate with the Activity.
        */
        try {
            mCallback = (OnMapsSelectedListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnMapSelectedListener");
        }
    }


}
