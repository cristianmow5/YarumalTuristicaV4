package com.example.cristian.yarumalturistica;


import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;


/**
 * A simple {@link Fragment} subclass.
 */
public class MapsFragment extends Fragment implements OnMapReadyCallback {

    private static final String ARG_ESTABLISHMENT = "establishment";

    private MapView mapView;
    private GoogleMap mMap;
    private int mEstablishment;

    public MapsFragment() {
        // Required empty public constructor
    }

    public static MapsFragment newInstance(int establishment) {

        MapsFragment fragment = new MapsFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_ESTABLISHMENT, establishment);
        fragment.setArguments(args);
        return fragment;

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View rootView = inflater.inflate(R.layout.fragment_maps, container, false);

        mEstablishment = getArguments().getInt(ARG_ESTABLISHMENT);

        mapView = (MapView) rootView.findViewById(R.id.map);
        mapView.onCreate(savedInstanceState);
        mapView.getMapAsync(this);

        return rootView;

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        mMap.setMyLocationEnabled(true);

        mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);

        LatLng udea = new LatLng(6.266953,-75.569111);
        mMap.addMarker(new MarkerOptions()
                .position(udea)
                .title("Univerisdad de Antioquia")
                //.icon(BitmapDescriptorFactory.fromResource(R.drawable.book))
                .snippet("Nuestra Alma máter"));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(udea,15));
    }

    @Override
    public void onResume() {
        //mapView.onResume();
        super.onResume();
    }

    @Override
    public void onDestroy() {
        //mapView.onDestroy();
        super.onDestroy();
    }

    @Override
    public void onLowMemory() {
        //mapView.onLowMemory();
        super.onLowMemory();
    }
}
