package com.example.cristian.yarumalturistica;

/**
 * Created by cristian on 29/03/17.
 */

public class Titular {

    private String titulo;
    private String subtitulo;
    private int imgId;

    public Titular(String tit, String sub, int id){
        titulo = tit;
        subtitulo = sub;
        imgId = id;
    }

    public String getTitulo(){
        return titulo;
    }

    public String getSubtitulo(){
        return subtitulo;
    }

    public int getImgId(){
        return imgId;
    }

}
