package com.example.cristian.yarumalturistica;

/**
 * Created by cristian on 15/04/17.
 */

public class Utils {

    public static final String SHARED_PREFERENCES_NAME = "MisPreferencias";
    public static final String SHARED_PREFERENCES_USERNAME = "username";
    public static final String SHARED_PREFERENCES_PASSWORD = "password";
    public static final String SHARED_PREFERENCES_EMAIL = "email";
    public static final String SHARED_PREFERENCES_LOGIN_STATUS = "loginStatus";


}
