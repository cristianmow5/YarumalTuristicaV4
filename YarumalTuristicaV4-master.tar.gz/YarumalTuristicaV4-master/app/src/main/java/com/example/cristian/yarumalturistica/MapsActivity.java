package com.example.cristian.yarumalturistica;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.util.Log;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private static final String EXTRA_USERNAME = "com.example.cristian.yarumalturistica.username";
    private static final String EXTRA_PASSWORD = "com.example.cristian.yarumalturistica.password";
    private static final String EXTRA_EMAIL = "com.example.cristian.yarumalturistica.email";
    private static final String EXTRA_POSITION_X = "com.example.cristian.yarumalturistica.positionx";
    private static final String EXTRA_POSITION_Y = "com.example.cristian.yarumalturistica.positiony";
    private String mUsername, mPassword, mEmail;
    private int mPositionX, mPositionY;

    private GoogleMap mMap;
    private LatLng mLatlng;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d("deg","oncreate");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        Bundle extras = getIntent().getExtras();
        mUsername = extras.getString(EXTRA_USERNAME);
        mPassword = extras.getString(EXTRA_PASSWORD);
        mEmail = extras.getString(EXTRA_EMAIL);
        mPositionX = extras.getInt(EXTRA_POSITION_X);
        mPositionY = extras.getInt(EXTRA_POSITION_Y);

        processPositionXY(mPositionX,mPositionY);

    }

    public static Intent newIntent(Context packageContext, String username,
                                    String password, String email, int positionX
                                    , int positionY ){

        Intent i = new Intent(packageContext, MapsActivity.class);
        i.putExtra(EXTRA_USERNAME,username);
        i.putExtra(EXTRA_EMAIL,email);
        i.putExtra(EXTRA_PASSWORD,password);
        i.putExtra(EXTRA_POSITION_X,positionX);
        i.putExtra(EXTRA_POSITION_Y,positionY);
        return i;
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        Log.d("deg","mapready");
        mMap = googleMap;


        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        mMap.setMyLocationEnabled(true);

        // Add a marker in Sydney and move the camera
        //LatLng sydney = new LatLng(-34, 151);
        //mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
        //mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));

        //LatLng udea = new LatLng(6.266953,-75.569111);
        mMap.addMarker(new MarkerOptions()
                            .position(mLatlng)
                            //.title("Univerisdad de Antioquia")
                            //.icon(BitmapDescriptorFactory.fromResource(R.drawable.book))
                            .snippet(""));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(mLatlng,15));

    }

    private void processPositionXY(int posX, int posY) {

        Log.d("deg","processPosition");
        Log.d("deg","posX="+String.valueOf(posX));
        Log.d("deg","posY="+String.valueOf(posY));
        if(posX == 1){
            switch (posY) {
                case 1:
                    //rest 1
                    mLatlng = new LatLng( 6.962779,-75.416986);
                    break;
                case 2:
                    //rest 2 6.965623, -75.426914
                    mLatlng = new LatLng(6.965623,-75.426914);
                    break;
                case 3:
                    //res 3 6.957647, -75.412662
                    mLatlng = new LatLng(6.957647,-75.412662);
                    break;
            }
        }
        else if (posX == 2){
            switch (posY){
                case 1:
                    //hotel 1 6.963932, -75.417015
                    mLatlng = new LatLng(6.963932,-75.417015);
                    break;
                case 2:
                    //hotel 2 6.963325, -75.417844
                    mLatlng = new LatLng(6.963325,-75.417844);
                    break;
                case 3:
                    //hotel 3  6.964250, -75.417776
                    mLatlng = new LatLng(6.964250,-75.417776);
                    break;
            }
        }
        else if (posX == 3){
            switch (posY){
                case 1:
                    //touristic 1 6.964250, -75.417776
                    mLatlng = new LatLng(6.964250, -75.417776);
                    break;
                case 2:
                    mLatlng = new LatLng(6.964250, -75.417776);
                    break;
                case 3:
                    //touristic 3 6.964868, -75.413917
                    mLatlng = new LatLng( 6.964868, -75.413917);
                    break;
            }
        }

    }
}
